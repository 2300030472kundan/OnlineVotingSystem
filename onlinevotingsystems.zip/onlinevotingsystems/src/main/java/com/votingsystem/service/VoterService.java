package com.votingsystem.service;

import com.votingsystem.model.Voter;
import com.votingsystem.repository.VoterRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class VoterService {

    @Autowired
    private VoterRepository voterRepository;

    public Voter register(Voter voter) {
        return voterRepository.save(voter);
    }

    public Voter login(String email, String password) {
        Voter voter = voterRepository.findByEmail(email);
        if (voter != null && voter.getPassword().equals(password)) {
            return voter;
        }
        return null;
    }

    public List<Voter> getAllVoters() {
        return voterRepository.findAll();
    }
}