package com.votingsystem.service;

import com.votingsystem.model.Election;
import com.votingsystem.repository.ElectionRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class ElectionService {

    @Autowired
    private ElectionRepository electionRepository;

    public Election addElection(Election election) {
        return electionRepository.save(election);
    }

    public List<Election> getAllElections() {
        return electionRepository.findAll();
    }

    public Optional<Election> getElectionById(Long id) {
        return electionRepository.findById(id);
    }

    public Election updateElection(Long id, Election updatedElection) {
        Optional<Election> existing = electionRepository.findById(id);
        if (existing.isPresent()) {
            Election e = existing.get();
            e.setTitle(updatedElection.getTitle());
            e.setDescription(updatedElection.getDescription());
            e.setStatus(updatedElection.getStatus());
            return electionRepository.save(e);
        }
        return null;
    }

    public void deleteElection(Long id) {
        electionRepository.deleteById(id);
    }
}