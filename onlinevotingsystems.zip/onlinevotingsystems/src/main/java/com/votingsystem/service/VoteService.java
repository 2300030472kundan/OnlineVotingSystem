package com.votingsystem.service;

import com.votingsystem.model.Vote;
import com.votingsystem.repository.VoteRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.*;

@Service
public class VoteService {

    @Autowired
    private VoteRepository voteRepository;

    public String castVote(Vote vote) {
        boolean alreadyVoted = voteRepository.existsByVoterIdAndElectionId(vote.getVoterId(), vote.getElectionId());
        if (alreadyVoted) {
            return "You have already voted in this election.";
        }
        voteRepository.save(vote);
        return "Vote successfully cast.";
    }

    public List<Vote> getAllVotes() {
        return voteRepository.findAll();
    }

    public Map<Long, Long> getResults(Long electionId) {
        List<Vote> votes = voteRepository.findByElectionId(electionId);
        Map<Long, Long> results = new HashMap<>();

        for (Vote vote : votes) {
            Long candidateId = vote.getCandidateId();
            results.put(candidateId, results.getOrDefault(candidateId, 0L) + 1);
        }

        return results;
    }
}