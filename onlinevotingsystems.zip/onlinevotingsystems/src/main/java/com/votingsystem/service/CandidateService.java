package com.votingsystem.service;

import com.votingsystem.model.Candidate;
import com.votingsystem.repository.CandidateRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class CandidateService {

    @Autowired
    private CandidateRepository candidateRepository;

    public Candidate addCandidate(Candidate candidate) {
        return candidateRepository.save(candidate);
    }

    public List<Candidate> getAllCandidates() {
        return candidateRepository.findAll();
    }

    public List<Candidate> getByElectionId(Long electionId) {
        return candidateRepository.findByElectionId(electionId);
    }

    public Optional<Candidate> getById(Long id) {
        return candidateRepository.findById(id);
    }

    public Candidate updateCandidate(Long id, Candidate updated) {
        Optional<Candidate> existing = candidateRepository.findById(id);
        if (existing.isPresent()) {
            Candidate c = existing.get();
            c.setName(updated.getName());
            c.setParty(updated.getParty());
            c.setSymbol(updated.getSymbol());
            c.setElectionId(updated.getElectionId());
            return candidateRepository.save(c);
        }
        return null;
    }

    public void deleteCandidate(Long id) {
        candidateRepository.deleteById(id);
    }
}