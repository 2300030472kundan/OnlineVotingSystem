package com.votingsystem.controller;

import com.votingsystem.model.Voter;
import com.votingsystem.service.VoterService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/voter")
@CrossOrigin(origins = "*")
public class VoterController {

    @Autowired
    private VoterService voterService;

    @PostMapping("/register")
    public Voter register(@RequestBody Voter voter) {
        return voterService.register(voter);
    }

    @PostMapping("/login")
    public Voter login(@RequestBody Voter voter) {
        return voterService.login(voter.getEmail(), voter.getPassword());
    }

    @GetMapping("/all")
    public List<Voter> getAllVoters() {
        return voterService.getAllVoters();
    }
}