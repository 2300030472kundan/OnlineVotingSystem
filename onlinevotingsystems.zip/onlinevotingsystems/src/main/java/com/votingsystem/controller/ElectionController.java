package com.votingsystem.controller;

import com.votingsystem.model.Election;
import com.votingsystem.service.ElectionService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/elections")
@CrossOrigin(origins = "*")
public class ElectionController {

    @Autowired
    private ElectionService electionService;

    @PostMapping("/add")
    public Election addElection(@RequestBody Election election) {
        return electionService.addElection(election);
    }

    @GetMapping("/all")
    public List<Election> getAll() {
        return electionService.getAllElections();
    }

    @GetMapping("/{id}")
    public Optional<Election> getById(@PathVariable Long id) {
        return electionService.getElectionById(id);
    }

    @PutMapping("/update/{id}")
    public Election update(@PathVariable Long id, @RequestBody Election election) {
        return electionService.updateElection(id, election);
    }

    @DeleteMapping("/delete/{id}")
    public void delete(@PathVariable Long id) {
        electionService.deleteElection(id);
    }
}