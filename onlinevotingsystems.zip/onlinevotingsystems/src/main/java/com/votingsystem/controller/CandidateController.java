package com.votingsystem.controller;

import com.votingsystem.model.Candidate;
import com.votingsystem.service.CandidateService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/candidates")
@CrossOrigin(origins = "*")
public class CandidateController {

    @Autowired
    private CandidateService candidateService;

    @PostMapping("/add")
    public Candidate addCandidate(@RequestBody Candidate candidate) {
        return candidateService.addCandidate(candidate);
    }

    @GetMapping("/all")
    public List<Candidate> getAll() {
        return candidateService.getAllCandidates();
    }

    @GetMapping("/{id}")
    public Optional<Candidate> getById(@PathVariable Long id) {
        return candidateService.getById(id);
    }

    @GetMapping("/election/{electionId}")
    public List<Candidate> getByElectionId(@PathVariable Long electionId) {
        return candidateService.getByElectionId(electionId);
    }

    @PutMapping("/update/{id}")
    public Candidate update(@PathVariable Long id, @RequestBody Candidate candidate) {
        return candidateService.updateCandidate(id, candidate);
    }

    @DeleteMapping("/delete/{id}")
    public void delete(@PathVariable Long id) {
        candidateService.deleteCandidate(id);
    }
}