package com.votingsystem.controller;

import com.votingsystem.model.Vote;
import com.votingsystem.service.VoteService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.*;

@RestController
@RequestMapping("/api/votes")
@CrossOrigin(origins = "*")
public class VoteController {

    @Autowired
    private VoteService voteService;

    @PostMapping("/cast")
    public String castVote(@RequestBody Vote vote) {
        return voteService.castVote(vote);
    }

    @GetMapping("/all")
    public List<Vote> getAllVotes() {
        return voteService.getAllVotes();
    }

    @GetMapping("/results/{electionId}")
    public Map<Long, Long> getResults(@PathVariable Long electionId) {
        return voteService.getResults(electionId);
    }
}