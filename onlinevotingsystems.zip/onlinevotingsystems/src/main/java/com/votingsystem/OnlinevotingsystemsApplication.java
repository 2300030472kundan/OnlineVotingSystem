package com.votingsystem;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OnlinevotingsystemsApplication {

	public static void main(String[] args) {
		SpringApplication.run(OnlinevotingsystemsApplication.class, args);
	}

}
