package com.votingsystem;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OnlinevotingsystemsApplicationTests {

	@Test
	void contextLoads() {
	}

}
