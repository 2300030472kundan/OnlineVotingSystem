# React + Vite

Online Voting Part-1 (Decrease speed for better experience)

https://github.com/user-attachments/assets/469b5627-0ff0-4895-a9fd-204c8aabecdc

Online Voting Part-2 (Decrease speed for better experience)

https://github.com/user-attachments/assets/a9f7739f-42db-41c7-817a-2909a477d905

