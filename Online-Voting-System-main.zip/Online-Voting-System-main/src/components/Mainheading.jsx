import React from "react";

export default function Mainheading() {
  return (
    <>
      <div className=" mainheading">
        <h4>ONLINE VOTING</h4>
        <h1>Speak for your Rights</h1>
      </div>
    </>
  );
}
